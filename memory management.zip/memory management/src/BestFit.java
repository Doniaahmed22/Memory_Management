import java.util.LinkedList;
import java.util.Arrays;
import java.util.Scanner;

public class BestFit {
    LinkedList<Partitions> partition = new LinkedList<>();
    LinkedList<Processes> process=new LinkedList<>();
    
    int allocation[];

    public BestFit(LinkedList<Partitions> partition, LinkedList<Processes> process)
    {
        this.partition = partition;
        this.process = process;
    }

  

    void run(){

        allocation = new int[process.size()];
        
        for (int i = 0; i < allocation.length; i++)
        {
            allocation[i] = -1;

        }
        
        for (int i = 0; i < process.size(); i++)
        {
            
            int wstIdx = -1;
            for (int j = 0; j < partition.size(); j++)
            {
                if (partition.get(j).Values >= process.get(i).size)
                {
                    if (wstIdx == -1)
                        wstIdx = j;
                    else if (partition.get(wstIdx).Values > partition.get(j).Values && partition.get(j).stat==true)
                        wstIdx = j;
                }
            }

           
            if (wstIdx != -1)
            {
                
                allocation[i] = wstIdx;

               
                int tmp =partition.get(wstIdx).Values;
                partition.get(wstIdx).Values = process.get(i).size;
                partition.get(wstIdx).setName(process.get(i).getName() );
                partition.get(wstIdx).stat = false;
                tmp-=process.get(i).size;

                if(tmp != 0)
                    partition.add((wstIdx+1), new Partitions(partition.size(),tmp,""));

            }

        }


        System.out.println("\n");

        for(int i = 0; i < partition.size(); i++)
        {
            if(partition.get(i).stat==false){
                System.err.println("Partition " + partition.get(i).ID + " ("+partition.get(i).Values+ " KB) => process"+partition.get(i).getName());

            }

            else if(partition.get(i).stat==true)
                System.err.println("Partition " + partition.get(i).ID + " ("+partition.get(i).Values+ " KB) => External fragment");


        }


        for (int i = 0; i < process.size(); i++)
        {
            if (allocation[i] == -1)
            {
                System.out.println("\nProcess " + (i+1) + " can not be allocated");
            }
        }

        Scanner sc=new Scanner(System.in);
        System.out.println("\nDo you want to compact?  1.yes 2.no");
        int select = sc.nextInt();

        Compact compact = new Compact(partition , process , allocation);

        if(select == 1)  compact.run();
    }


}