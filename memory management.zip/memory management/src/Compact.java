import java.util.LinkedList;
public class Compact {
    LinkedList<Partitions> partition = new LinkedList<>();
    LinkedList<Processes> process = new LinkedList<>();
   
    int allocation[];

    public Compact(LinkedList<Partitions> partition , LinkedList<Processes> process , int allocation[])
    {
        this.partition = partition;
        this.process = process;
        this.allocation = allocation;
    }

    void run()
    {
        int sum=0;
        int sz=partition.size();

        for(int i=0;i<partition.size();i++){
            if(partition.get(i).stat==true){
                sum=sum+partition.get(i).Values;
                partition.remove(partition.get(i));
                i--;
            }
        }
        partition.add(new Partitions(sz,sum,""));

        for (int i = 0; i < allocation.length; i++) {
            if(allocation[i]==-1 && partition.get((partition.size()-1)).Values > process.get(i).size){
                sum = sum - process.get(i).getSize();//210-100 -> 110
                partition.get((partition.size()-1)).Values=process.get(i).size;
                partition.get((partition.size()-1)).stat=false;
                partition.get((partition.size()-1)).name=process.get(i).getName();
                partition.add(new Partitions((sz+1),sum,""));
                //any thing//
                allocation[i]=1;
                sz++;
            }
            else if (allocation[i]==-1 && partition.get((partition.size()-1)).Values == process.get(i).size){
                partition.get((partition.size()-1)).Values=process.get(i).size;
                partition.get((partition.size()-1)).stat=false;
                partition.get((partition.size()-1)).name=process.get(i).getName();
                //any thing//
                allocation[i]=1;
            }

        }
        for(int i=0;i<partition.size();i++){
            if(partition.get(i).stat==false)
                System.err.println("partition"+partition.get(i).ID+" ("+partition.get(i).Values+" KB) => process"+partition.get(i).getName());
            else if(partition.get(i).stat==true){
                System.err.println("partition"+partition.get(i).ID+" ("+partition.get(i).Values+" KB) => "+"External fragment");
            }
        }
        for (int i = 0; i < allocation.length; i++){
            if(allocation[i]==-1)
                System.out.println("process "+process.get(i).getName()+" can not be allocated");
        }
    }

}
