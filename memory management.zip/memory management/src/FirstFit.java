import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Scanner;

public class FirstFit {
    static int size=0;
    LinkedList<Partitions> partitionQueue = new LinkedList<>();
    LinkedList<Processes> processQueue=new LinkedList<>();

    int allocation[];
    public FirstFit(LinkedList<Partitions> partitionQueue, LinkedList<Processes> processQueue ){
        this.partitionQueue=partitionQueue;
        this.processQueue=processQueue;
    }
     public void run(){

        allocation = new int[processQueue.size()];
        for (int i = 0; i < allocation.length; i++)
        {
            allocation[i] = -1;

        }
        //boolean f;
        size=partitionQueue.size();
        for(int i=0;i<processQueue.size();i++){
            //f=false;
            for(int j=0;j<size;j++){
                if(partitionQueue.get(j).getName().equals("")){
                    if(partitionQueue.get(j).getValues() == processQueue.get(i).getSize()){
                        String processName = processQueue.get(i).getName();
                        partitionQueue.get(j).setName(processName);
                        partitionQueue.get(j).stat=false;
                        //f=false;
                        allocation[i]=1;
                        break;
                    }
                    else if(partitionQueue.get(j).getValues() > processQueue.get(i).getSize()){
                        String processName = processQueue.get(i).getName();
                        partitionQueue.get(j).setName(processName);
                        partitionQueue.get(j).stat=false;
                        Partitions p=new Partitions();
                        int name = size;
                        int size_of_newPartition=partitionQueue.get(j).getValues()-processQueue.get(i).getSize();
                        partitionQueue.get(j).setValues(processQueue.get(i).getSize());
                        p.setID(name);
                        p.setValues(size_of_newPartition);
                        p.setName("");
                        partitionQueue.add(j+1,p); //addAll
                        size+=1;
                        //f=false;
                        allocation[i]=1;
                        break;
                    }

                }
            }
        }

        System.out.println("\nFirst Fit Algorithm : ");
        for(int i=0;i<size;i++){
            if(!(partitionQueue.get(i).getName().equals(""))){
                
                System.out.println("Partition "+partitionQueue.get(i).getID()+" ("+partitionQueue.get(i).getValues()+" KB) =>"+" process"+partitionQueue.get(i).getName());
            }
            else if (partitionQueue.get(i).getName().equals("")) {
                System.out.println("Partition "+partitionQueue.get(i).getID()+" ("+partitionQueue.get(i).getValues()+" KB) =>"+" External fragment");
            }
        }
        for(int i=0;i<processQueue.size();i++){
            if((allocation[i]==-1))
                System.out.println("\nProcess "+processQueue.get(i).getName()+" can not be allocated");
        }
         Scanner sc=new Scanner(System.in);
         System.out.println("\nDo you want to compact?  1.yes 2.no");
         int select = sc.nextInt();

         Compact compact = new Compact(partitionQueue , processQueue, allocation);

         if(select == 1)  compact.run();
    }


}
