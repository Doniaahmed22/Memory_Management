import java.util.LinkedList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        LinkedList<Processes> proces=new LinkedList<Processes>();
        LinkedList <Partitions> parts=new LinkedList<Partitions>();
        String name = "Process";


        Scanner sc=new Scanner(System.in);
        System.err.println("Enter number of partitions:");
        int num_parts=sc.nextInt();

        for (int i = 0; i < num_parts; i++)
        {
            System.err.print("Partition" + i + "  ");
            int part_size=sc.nextInt();

            parts.add(new Partitions((i),part_size,""));
        }

        System.err.println("\nEnter number of Processes: ");
        int num_pro=sc.nextInt();

        for (int i = 1; i <= num_pro ; i++)
        {
            System.err.print("Enter name and its size:\nProcesses" + i + " ");
            int sizeOfProcess=sc.nextInt();
            name=Integer.toString(i);
            proces.add(new Processes(sizeOfProcess , name));
        }

        FirstFit first = new FirstFit(parts , proces);
        WorstFit worst = new WorstFit(parts , proces);
        BestFit best = new BestFit(parts , proces);
        System.out.println("\n\nSelect the policy you want to apply:\n1.First_Fit policy.\n2.Worst_Fit policy.\n3.Best_Fit policy.\n\nSelect policy:");

        int select = sc.nextInt();

        if(select == 1)  first.run();

        if(select == 2)  worst.run();

        if(select == 3)  best.run();


    }
}