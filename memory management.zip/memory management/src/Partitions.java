
import java.io.Console;

public class Partitions {
    int ID ;
    int Values;
    String name;
    boolean stat = true ;
    
    public Partitions(){}
    public Partitions(int id ,int val ,String s)
    {
        this.ID=id;
        this.Values=val;
        this.name=s;

    }
    public void setID(int iD)
    {
        ID = iD;
    }
    public void setName(String name)
    {
        this.name = name;
    }
    public void setValues(int values)
    {
        Values = values;
    }
    public int getID()
    {
        return ID;
    }
    public int getValues()
    {
        return Values;
    }
    public String getName()
    {
        return name;
    }

}
